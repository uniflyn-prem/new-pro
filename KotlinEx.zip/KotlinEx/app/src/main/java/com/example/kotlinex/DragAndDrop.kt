package com.example.kotlinex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DragAndDrop : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drag_and_drop)

    }
}