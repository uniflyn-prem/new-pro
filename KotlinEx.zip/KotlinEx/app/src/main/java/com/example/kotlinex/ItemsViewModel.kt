package com.example.kotlinex

data class ItemsViewModel(val image:Int,val text:String,val id:String)

{

}