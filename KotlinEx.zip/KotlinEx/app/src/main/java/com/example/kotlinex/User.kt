package com.example.kotlinex

data class User(val firstName:String,val lastName:String,val age:String)
